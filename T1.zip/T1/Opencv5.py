import cv2
import numpy as np

cap = cv2.VideoCapture(0)
#if __name__ == '__main__':
while(True):
    #cap = cv2.VideoCapture()  # 初始化摄像头
    #ret,Img = cap.read()
    Img = cv2.imread('C:/Users/89236/Desktop/video/image/test2.png')  # 读入-幅图像
    #cv2.imread('C:/Users/89236/Desktop/video/image/test2.png') #读入-幅图像
    kerne1_2 =np. ones((2, 2), np. uint8)#2x2的卷积核
    kernel_3 = np. ones ((3, 3), np. uint8)#3x3的卷积核
    kernel_4 = np. ones((4, 4), np. uint8)#4x4的卷积核
    if Img is not None :#判断图片是否读入
        HSV = cv2.cvtColor(Img, cv2.COLOR_BGR2HSV)  # 把 BGR 图像转换为 HSV 格式
        #红色1
        #Lower = np.array([156, 43, 46])#颜色下限
        #Upper = np.array([180, 255, 255])#颜色上限
        #红色2
        Lower = np.array([0, 43, 46])
        Upper = np.array([10, 255, 255])
        mask = cv2.inRange(HSV, Lower, Upper)
        erosion = cv2.erode(mask, kernel_4, iterations = 1)
        erosion = cv2.erode(erosion, kernel_4, iterations = 1)
        dilation = cv2.dilate(erosion, kernel_4, iterations = 1)
        dilation = cv2.dilate(dilation, kernel_4, iterations = 1)
        target = cv2.bitwise_and(Img, Img, mask=dilation)
        ret, binary = cv2.threshold(dilation, 127, 255, cv2.THRESH_BINARY)
        contours, hierarchy = cv2.findContours(binary,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
        maxArea = 0
        maxContour = contours
        for i in contours:  # 遍历所有的轮廓
            area = cv2.contourArea(i);
            if area > maxArea:
                maxArea = area
                maxContour = i+1
            x,y,w,h = cv2.boundingRect(maxContour)  # 将轮廓分解为识别对象的左上角坐标和宽、高
            cv2.rectangle(Img, (x, y), (x + w, y + h), (0, 255,255), 3)


        cv2.imshow('Img', Img)
        cv2.imwrite('color2.jpg', Img)  # 将画上矩形的图形保存到当前目录
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# When everything done, release the capture
cap.release()
cv2.destroyAllWindows()
