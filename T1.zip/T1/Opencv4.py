# -*- coding: utf-8 -*
import cv2
cap = cv2.VideoCapture(0)
#ret=cap.set(3,320)#宽度
#ret=cap.set(4,240)#需要一起用 240*320

#width=cap.get(3)
#height=cap.get(4)
#print(width)
#print(height)

while True:
    ret,frame = cap.read()
    #ret
    #print(frame.shape)
    # Our operations on the frame come here
    #gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    # Display the resulting frame
    cv2.imshow('camera show',frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
        # When everything done, release the capture
        cap.release()
        cv2.destroyAllWindows()