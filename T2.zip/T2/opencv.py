import time
import sys

from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from cv2 import *
from PyQt5.QtCore import QTimer


class VideoBox(QWidget):
    VIDEO_TYPE_OFFLINE = 0
    VIDEO_TYPE_REAL_TIME = 1

    STATUS_INIT = 0
    STATUS_PLAYING = 1
    STATUS_PAUSE = 2


    def __init__(self):
        QWidget.__init__(self)
        self.status = self.STATUS_INIT  # 0: init 1:playing 2: pause

        # 组件展示
        self.pictureLabel = QLabel()
        control_box = QHBoxLayout()
        control_box.setContentsMargins(0, 0, 0, 0)
        layout = QVBoxLayout()
        layout.addWidget(self.pictureLabel)
        layout.addLayout(control_box)
        self.setLayout(layout)
        self.playCapture = VideoCapture(0)

    def show_video_images(self):
        if self.playCapture.isOpened():

            success, frame = self.playCapture.read()
            if success:
                height, width = frame.shape[:2]
                if frame.ndim == 3:
                    rgb = cvtColor(frame, COLOR_BGR2RGB)
                elif frame.ndim == 2:
                    rgb = cvtColor(frame, COLOR_GRAY2BGR)

                temp_image = QImage(rgb.flatten(), width, height, QImage.Format_RGB888)
                temp_pixmap = QPixmap.fromImage(temp_image)
                self.pictureLabel.setPixmap(temp_pixmap)
            else:
                print("read failed, no frame data")
                return
        else:
            print("open file or capturing device error, init again")


if __name__ == "__main__":
    mapp = QApplication(sys.argv)
    mw = VideoBox()

    timer = QTimer()
    timer.timeout.connect(mw.show_video_images)  # 计时结束调用operate()方法
    timer.start(100)  # 设置计时间隔并启动

    mw.show()
    sys.exit(mapp.exec_())
