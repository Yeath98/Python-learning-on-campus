import pandas as pd
import numpy as np
import matplotlib.pyplot as pyplot

img_train = pd.read_csv('train.csv')  # 读取kaggle数据集，一维数组，代表28*28的图像
img_train = np.array(img_train)  # 这个是关键，转化为数组
#print(img_train)

trainSet = np.zeros((28, 28))
trainSet2 = np.zeros((1, 784));
#print(trainSet)
#print(trainSet2)
trainSet2 = img_train[0:][0:]#[0:784]
trainSet = trainSet2.reshape(27, 28)

print(trainSet)
pyplot.imshow(trainSet)
pyplot.show()